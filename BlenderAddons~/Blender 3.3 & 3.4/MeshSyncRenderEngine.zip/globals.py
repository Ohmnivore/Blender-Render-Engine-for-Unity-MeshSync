bridge = None
pip_manager = None
